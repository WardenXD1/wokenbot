import discord
from redbot.core import commands, Config
from datetime import datetime

class MentionTracker(commands.Cog):
    """Tracks and displays the last 5 mentions a user has received."""
    def __init__(self, bot):
        self.bot = bot
        self.config = Config.get_conf(self, identifier=12345567890, force_registration=True)
        default_user = {"mentions": []}
        self.config.register_user(**default_user)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        mentions = message.mentions
        if not mentions:
            return

        for mention in mentions:
            async with self.config.user(mention).mentions() as mention_list:
                current_time_unix = int(datetime.utcnow().timestamp())
                mention_data = {
                    "content": message.content,
                    "jump_url": message.jump_url,
                    "author": message.author.display_name,  # Add the display name of the author
                    "time_unix": current_time_unix  # Convert current time to Unix timestamp for embed
                }
                mention_list.append(mention_data)
                if len(mention_list) > 5:
                        mention_list.pop(0)

    @commands.guild_only()
    @commands.command(aliases=['mentions', 'mention'])
    async def mentioned(self, ctx):
        """Display the last 5 mentions you have received"""
        mention_list = await self.config.user(ctx.author).mentions()
        if not mention_list:
            await ctx.send("No mentions tracked.")
            return

        embed = discord.Embed(title="Your last 5 mentions", color=await ctx.embed_color())
        for idx, mention_data in enumerate(mention_list, start=1):
            mention_content = f"Content: {mention_data['content']}\n[Jump to message]({mention_data['jump_url']})"
            mention_content += f"\nTimestamp: <t:{mention_data['time_unix']}:R>"  # Use Discord timestamp
            embed.add_field(name=f"Mentioned by: {mention_data['author']}\n", value=mention_content, inline=False)
        await ctx.send(embed=embed)
