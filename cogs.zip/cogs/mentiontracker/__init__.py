from .mentiontracker import MentionTracker

async def setup(bot):
    await bot.add_cog(MentionTracker(bot))
