# Meow Help

Meow!<br/><br/><br/>My girlfriend had a dream about this cog, so I had to make it ¯\_(ツ)_/¯<br/><br/>Use `[p]automeow` to toggle automatic meow response.

# .automeow
Toggle automatic meow response<br/>
 - Usage: `.automeow`
# .meow

 - Usage: `.meow`
