### Supports slash commands
<h1></h1>

# INFO
---
➥ Banner is something just like avatar, yet i haven't so far seen a cog to retrieve user banner. But look no further; this is the only cog for retrieving user banners you will ever need.

# USAGE
---
➥ [ OPTIONAL ] Run `banner_embed` to customize the embed holding the banner, or to disable the embed completely, and send the image as a normal message.
<br/> <br/>
➥ `banner <user>`
<br/> <br/>
➥ [user] is an optional argument. If you simply run `banner`, it will return your own banner.

# NOTE
---
➥ Currently theres no way to choose between guild/global banner of a user. I will add the option when the functionality to do so comes up.