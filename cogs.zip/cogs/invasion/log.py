"""Log for Invasion cog."""

import logging

__all__ = ["log"]

log = logging.getLogger("red.cogs.invasion")