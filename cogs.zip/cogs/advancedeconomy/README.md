# AdvancedEconomy

# Changelog

## v1.0.0

#### Release of AdvancedEconomy, contains `payday`, `work`, `bal`, and `economyset` commands.
