## My utils

Hello there! If you're contributing or taking a look, everything in this folder
is synced from a master repo at https://github.com/Vexed01/vex-cog-utils by GitHub Actions -
so it's probably best to look/edit there.

---

Last sync at: 2023-02-16 14:37:06 UTC

Version: `2.6.1`

Commit: [`b98072829ca902ef207688334da34f8e6c1da1e8`](https://github.com/Vexed01/vex-cog-utils/commit/b98072829ca902ef207688334da34f8e6c1da1e8)
