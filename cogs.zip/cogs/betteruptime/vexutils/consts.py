DOCS_BASE = "This cog has docs! Check them out at\nhttps://s.vexcodes.com/c/{}"

CHECK = "\N{HEAVY CHECK MARK}\N{VARIATION SELECTOR-16}"
CROSS = "\N{CROSS MARK}"

RED_CIRCLE = "\N{LARGE RED CIRCLE}"
GREEN_CIRCLE = "\N{LARGE GREEN CIRCLE}"

SNOWFLAKE_REGEX = r"\b\d{17,20}\b"
