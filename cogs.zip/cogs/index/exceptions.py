class IndexException(Exception):
    pass


class NoCogs(IndexException):
    pass
