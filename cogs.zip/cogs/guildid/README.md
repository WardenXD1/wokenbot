# GuildID Help

# istats
 - Usage: `[p]istats <invite_link> `

Returns server stats from an invite link

# serverinvites
 - Usage: `[p]serverinvites `

Get a list of server invites

