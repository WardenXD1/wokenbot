from random import choice

# Stuff for the cog


def emoji():
    """Randomize footer emojis."""
    EMOJIS = [
        "\N{AUBERGINE}",
        "\N{SMIRKING FACE}",
        "\N{PEACH}",
        "\N{SPLASHING SWEAT SYMBOL}",
        "\N{BANANA}",
        "\N{KISS MARK}",
    ]
    emoji = choice(EMOJIS)
    return emoji


REDDIT_BASEURL = "https://api.reddit.com/r/{sub}/random"
MARTINE_API_BASE_URL = "https://api.martinebot.com/v1/images/subreddit"
IMGUR_LINKS = ("http://imgur.com", "https://m.imgur.com", "https://imgur.com")
NOT_EMBED_DOMAINS = (
    "gfycat.com/",
    "gifdeliverynetwork.com/",
    "redgifs.com",
    "imgur.com/gallery/",
    "imgur.com/a/",
    ".gifv",
)
GOOD_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".mp4", ".gifv")

# Subreddits
FOUR_K = [
    "Hegre",
    "HighResNSFW",
    "NSFW_Wallpapers",
    "UHDnsfw",
    "closeup",
]
AHEGAO = ["AhegaoGirls", "EyeRollOrgasm", "O_Faces", "RealAhegao"]
ASS = [
    "AssOnTheGlass",
    "AssholeBehindThong",
    "ButtsAndBareFeet",
    "HungryButts",
    "Mooning",
    "SnakeButt",
    "TheUnderbun",
    "Upshorts",
    "ass",
    "asshole",
    "assinthong",
    "asstastic",
    "beautifulbutt",
    "bigasses",
    "booty",
    "datgap",
    "girlsinleggings",
    "girlsinyogapants",
    "hugeass",
    "paag",
    "pawg",
    "facedownassup",
]
ASIANPORN = [
    "AsianCuties",
    "AsianHotties",
    "AsianNSFW",
    "AsianPorn",
    "AsiansGoneWild",
    "KoreanHotties",
    "NSFW_Japan",
    "bustyasians",
    "juicyasians",
]
ANAL = [
    "AnalGW",
    "MasterOfAnal",
    "NotInThePussy",
    "anal",
    "analinsertions",
    "assholegonewild",
    "buttsthatgrip",
]


BLOWJOB = [
    "AsianBlowjobs",
    "Blowjobs",
    "OralCreampie",
    "SwordSwallowers",
    "blowjobsandwich",
]
BOOBS = [
    "BestTits",
    "Boobies",
    "BustyPetite",
    "Nipples",
    "PerfectTits",
    "PiercedNSFW",
    "TinyTits",
    "Titties",
    "boobbounce",
    "boobgifs",
    "boobs",
    "ghostnipples",
    "naturaltitties",
    "tits",
]
COSPLAY = [
    "CosplayLewd",
    "Cosplayheels",
    "nsfwcosplay",
]
CUMSHOTS = [
    "GirlsFinishingTheJob",
    "amateurcumsluts",
    "bodyshots",
    "cumfetish",
    "cumontongue",
    "cumshots",
    "facialcumshots",
    "pulsatingcumshots",
]
DEEPTHROAT = [
    "DeepThroatTears",
    "SwordSwallowers",
    "deepthroat",
]


DOUBLE_P = ["Technical_DP", "doublepenetration"]


FACIALS = ["FacialFun", "facialcumshots"]


LESBIANS = [
    "HDLesbianGifs",
    "Lesbian_gifs",
    "StraightGirlsPlaying",
    "dyke",
    "girlskissing",
    "lesbians",
    "mmgirls",
    "scissoring",
]
MILF = [
    "AgedBeauty",
    "MILFs",
    "Milfie",
    "amateur_milfs",
    "cougars",
    "hairymilfs",
    "maturemilf",
    "milf",
]
ORAL = [
    "AsianBlowjobs",
    "Blowjobs",
    "DeepThroatTears",
    "OralCreampie",
    "SwordSwallowers",
    "blowjobsandwich",
    "cunnilingus",
    "deepthroat",
]
PUBLIC = [
    "ChangingRooms",
    "Flashing",
    "FlashingAndFlaunting",
    "FlashingGirls",
    "NSFW_Outdoors",
    "NotSafeForNature",
    "PublicFlashing",
    "WoodNymphs",
    "bitchinbubba",
    "casualnudity",
    "exposedinpublic",
    "gwpublic",
    "holdthemoan",
    "publicplug",
    "snowgirls",
]
PUSSY = [
    "GodPussy",
    "HairyPussy",
    "Innies",
    "LabiaGW",
    "LipsThatGrip",
    "PussyFlashing",
    "PussyMound",
    "grool",
    "peachlips",
    "pussy",
    "rearpussy",
    "DangleAndJingle",
]
REAL_GIRLS = [
    "CellShots",
    "ChangingRooms",
    "Nude_Selfie",
    "RealGirls",
    "selfpix",
]


RULE_34 = [
    "Overwatch_Porn",
    "Rule34LoL",
    "Rule_34",
    "rule34",
]
SQUIRTS = ["squirting", "squirting_gifs", "wetspot", "grool"]
THIGHS = [
    "ThickThighs",
    "Thigh",
    "datgap",
    "leggingsgonewild",
    "legs",
    "theratio",
    "thighhighs",
]
THREESOME = [
    "AirTight",
    "SpitRoasted",
    "Threesome",
    "Xsome",
    "amateur_threesomes",
    "groupsex",
    "gangbang",
    "blowbang",
]

WILD = [
    "ArtGW",
    "AsiansGoneWild",
    "BigBoobsGW",
    "BigBoobsGonewild",
    "GWCouples",
    "GWNerdy",
    "GoneWildSmiles",
    "LabiaGW",
    "LingerieGW",
    "PetiteGoneWild",
    "Swingersgw",
    "TallGoneWild",
    "UnderwearGW",
    "altgonewild",
    "bigonewild",
    "dirtysmall",
    "gonewild",
    "gonewildcolor",
    "gonewildcouples",
    "gonewildcurvy",
    "gwpublic",
    "workgonewild",
]
# Other APIs
NEKOBOT_HENTAI = choice(["hentai_anal", "hentai"])
NEKOBOT_URL = "https://nekobot.xyz/api/image?type={}"
