### Supports slash commands
<h1></h1>

# INFO
---
➥ Gulag cog works by stripping away all permissions of the specified user; and restricting them to a single channel.

# USAGE
---
➥ Set the gulag channel with `gulagset channel <channel>` command and the gulag role with `gulagset role <role` command.
<br/> <br/>
➥ After setup, simply run `gulag <user>` or `bail <user>`
<br/> <br/>
➥ `gulag` will take away all roles (assuming bot's role is higher than those roles) and give the gulag role to member. `bail` will take away gulag role and give back the roles the member previously had.

# NOTE
---
➥ For the sake of simplicity, the cog has limited features as of now. If i feel like it, i will add features to annoy the users in gulag.
