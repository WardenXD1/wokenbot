"""
MIT License

Copyright (c) 2020-2023 phenom4n4n
Copyright (c) 2023-present sravan1946

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from redbot.core import commands

try:
    from redbot.core.core_commands import MAX_PREFIX_LENGTH, MINIMUM_PREFIX_LENGTH
except ImportError:
    MAX_PREFIX_LENGTH = 25
    MINIMUM_PREFIX_LENGTH = 1


class PrefixConverter(commands.Converter):
    async def convert(self, ctx: commands.Context, argument: str) -> str:
        if len(argument) > MAX_PREFIX_LENGTH and not await ctx.bot.is_owner(ctx.author):
            raise commands.BadArgument(
                f"Prefixes cannot be above {MAX_PREFIX_LENGTH} in length."
            )
        if len(argument) < MINIMUM_PREFIX_LENGTH and not await ctx.bot.is_owner(
            ctx.author
        ):
            raise commands.BadArgument(
                f"Prefixes cannot be below {MINIMUM_PREFIX_LENGTH} in length."
            )
        if argument.startswith("/"):
            raise commands.BadArgument(
                "Prefixes cannot start with a slash (`/`) because it conflicts with Discord's slash commands."
            )
        return argument
