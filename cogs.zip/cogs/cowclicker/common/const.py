COW_IMAGE = "https://upload.wikimedia.org/wikipedia/en/1/1f/Cow_Clicker_cover.png"
