class ConnectionTimeoutError(Exception):
    message: str


class UNCPathError(Exception):
    message: str


class DirectoryError(Exception):
    message: str
