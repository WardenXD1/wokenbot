"""
MIT License

Copyright (c) 2024-present japandotorg

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from typing import TYPE_CHECKING, Dict, List, Protocol

if TYPE_CHECKING:
    from .core import AutoReact


class CacheProtocol(Protocol):
    def __init__(self, cog: "AutoReact") -> None: ...

    async def initialize(self) -> None: ...


class Cache(CacheProtocol):
    def __init__(self, cog: "AutoReact") -> None:
        self.cog: "AutoReact" = cog
        self.autoreact: Dict[int, Dict[str, List[str]]] = {}
        self.event: Dict[int, Dict[str, List[str]]] = {}

    async def initialize(self) -> None:
        config: Dict[int, Dict[str, Dict[str, List[str]]]] = await self.cog.config.all_guilds()
        for _id, data in config.items():
            self.autoreact[_id] = data["reaction"]
            self.event[_id] = data["event"]
